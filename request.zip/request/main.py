import requests

url2 = 'http://10.135.80.61:8090/scmaidochub/api/ai/dochub/docs/single'
headers = {
           'Authorization': 'Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImF1dGgiOiJST0xFX0FETUlOLFJPTEVfVVNFUiIsImV4cCI6MTUyNjYyMjc0OH0.FY43sKZVDL-0pXQ_8bEG2fdMl8HnUcxaLEIcCTgRdIQ9wdRHc2TtJWaq3_W-ex8xGwCU9X4jQbhL16ThkD-bpg'
          }
file = open('test.py','rb')
data = {
    "file":("test.py",file)
}

r = requests.post(url2, headers = headers, files = data)
print(r.text)