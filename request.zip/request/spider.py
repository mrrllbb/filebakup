# -*- coding:utf-8 -*-
from imp import reload

import requests
from bs4 import BeautifulSoup
import re
from decode_script import DecodeScript
# from hero.proxy import proxy
from decode_fontfile import DecodeFontFile
import sys

reload(sys)
# sys.setdefaultencoding('utf8')


class ParseHtml(object):
    def __init__(self):
        self.header = {"User-Agent": "Mozilla/6.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36"}

    def get_html_doc(self, url):
        """根据传入的url,获得所有口碑页面的html代码"""
        # s = requests.Session()
        resp = requests.request("GET", url, headers=self.header)
        if resp.status_code != 200:
            return 1
        else:
            return resp.content.decode('gb2312','ignore')

    def get_text_con(self, html_doc):
        """解析网页源代码,利用css属性,获得口碑内容部分的源代码"""
        soup = BeautifulSoup(html_doc,'html.parser')
        print(html_doc)
        mouth_item = soup.findAll('div',attrs={'class':'mouth-item'})[-1]
        text_con = mouth_item.find(class_="text-con")
        return text_con

    def get_font_url(self, html_doc):
        """利用正则获取字体文件链接"""
        regex = r'\w+\.\w+\..*?ttf'
        font_url = re.findall(regex, html_doc)[0]
        return font_url


def run():
    url = "https://k.autohome.com.cn/detail/view_01bcj6qdbw64tk4d1p6rrg0000.html"
    parse = ParseHtml()
    html_doc = parse.get_html_doc(url)  # 获得网页源代码 ,如果状态码不是200,则返回404
    if html_doc == 1:
        run()
    else:
        # 获取字体文件链接, 并下载字体文件
        font_url = parse.get_font_url(html_doc)
        decode_fontfile = DecodeFontFile()

        decode_fontfile.download_fontfile(font_url)
        text_con = parse.get_text_con(html_doc)
        decode_script = DecodeScript()
        list_text = decode_script.get_text_con(text_con, decode_fontfile)
        for text in list_text:
            for key, value in text.items():
                print(key + ":" + value)


run()