from fontTools.ttLib import TTFont

font = TTFont('fonts/wKgHGlsV94yAM1w1AADV7LZu3nM87..ttf')
font.saveXML('wKgHGlsV94yAM1w1AADV7LZu3nM87.xml')
