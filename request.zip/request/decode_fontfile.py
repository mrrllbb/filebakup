# -*- coding:utf-8 -*-
"""解析字体文件"""
from fontTools.ttLib import TTFont
import requests
import re
import os

list_font = [' ', '地', '七', '耗', '更', '只', '短', '控', '档', '硬', '味', '很', '里', '九', '近', '二', '五',
             '低', '保', '光', '八', '公', '六', '养', '级', '比', '副', '加', '门', '矮', '电', '一', '皮', '三', '真', '着', '路', '的',
             '小', '性', '了', '远', '好', '量', '实', '孩', '来', '下', '大', '启', '呢', '油', '和', '响', '四', '的', '坏', '排', '动',
             '多', '有', '灯', '外', '盘', '音', '少', '软', '十', '冷', '空', '内', '是', '雨', '不', '无', '左', '开', '当', '泥', '长',
             '坐', '过', '手', '自', '中', '高', '得', '上', '身', '机', '问']


class DecodeFontFile(object):
    def __init__(self):
        self.file_path = ""
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36"
        }

    def download_fontfile(self, font_url):
        font_url = "http://" + font_url
        cont = requests.get(font_url, headers=self.headers).content
        file_name = font_url.split('/')[-1]
        # file_name = re.findall(r'\w{20,}[\s\S]*?ttf', font_url)[0]
        self.file_path = "./fonts/" + file_name
        with open(self.file_path, "wb") as f:
            f.write(cont)

    # 创建 self.font 属性
    def get_glyph_id(self, glyph):
        ttf = TTFont(self.file_path)
        # gly_list = ttf.getGlyphOrder()  # 获取 GlyphOrder 字段的值
        index = ttf.getGlyphID(glyph)
        # os.remove(self.file_path)
        return index

    def get_font(self, glyph):
        id = self.get_glyph_id(glyph)
        return list_font[id]

